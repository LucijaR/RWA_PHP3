<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ispis teksta</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $unosTeksta = isset($_GET["unosTeksta"]) ? $_GET["unosTeksta"] : '';
    $broj = isset($_GET["broj"]) ? intval($_GET["broj"]) : 0;

    for ($i = 1; $i <= $broj; $i++) {
        echo "$i. $unosTeksta<br>";
    }
}
?>

</body>
</html>