<!DOCTYPE html>
<head>
    <title>Kalkulator</title>
	
<?php 
function Operacija($brojA, $brojB, $operacija) 
{
    if (empty($brojA) || empty($brojB) || empty($operacija)) 
	{
        return false;
    }
    if ($operacija !== '+' && $operacija !== '-' && $operacija !== 'x' && $operacija !== '/') 
	{
        return false;
    }
    switch ($operacija) 
	{
        case '+':
            return $brojA + $brojB;
        case '-':
            return $brojA - $brojB;
        case 'x':
            return $brojA * $brojB;
        case '/':
            return $brojA / $brojB;
        default:
            return false;
    }
}
$brojA = '';
$brojB = '';
$operacija = '';
$rezultat = '';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $brojA = isset($_GET["brojA"]) ? $_GET["brojA"] : '';
    $brojB = isset($_GET["brojB"]) ? $_GET["brojB"] : '';
    $operacija = isset($_GET["operacija"]) ? $_GET["operacija"] : '';
    $rezultat = Operacija($brojA, $brojB, $operacija);
}
if ($rezultat !== false) 
{
        print("<hr>");
        print("Rezultat je: $rezultat");
        print("<hr>");
}
?>
</head>
<body>
    <h2>Kalkulator</h2>
    
    <form method="get" action="kalkulator.php">
        A broj: <input type="text" name="brojA" value="<?php echo $brojA; ?>" required>
        Operacija:
        <select name="operacija" required>
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="x">x</option>
            <option value="/">/</option>
        </select>
        B broj: <input type="text" name="brojB" value="<?php echo $brojB; ?>" required>
        <input type="submit" value="Rezultat">
    </form>
	
</body>
</html>