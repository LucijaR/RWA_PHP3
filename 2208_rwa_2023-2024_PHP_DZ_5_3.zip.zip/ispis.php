<!DOCTYPE html>
<head>
    <title>Odaberite opciju</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") 
{
    $odabraniGumb = isset($_GET["odabraniGumb"]) ? $_GET["odabraniGumb"] : '';
    switch ($odabraniGumb) 
	{
        case 'A':
            print("Odabrali ste opciju A");
            break;
        case 'B':
            print( "Odabrali ste opciju B");
            break;
        case 'C':
            print("Odabrali ste opciju C");
            break;
        default:
             print("Niste odabrali nijedno dugme");
    }
}
?>
<form method="get" action="ispis.php">
    <h2>Odaberite opciju</h2>
    <button type="submit" name="odabraniGumb" value="A">A</button>
    <button type="submit" name="odabraniGumb" value="B">B</button>
    <button type="submit" name="odabraniGumb" value="C">C</button>
</form>

</body>
</html>