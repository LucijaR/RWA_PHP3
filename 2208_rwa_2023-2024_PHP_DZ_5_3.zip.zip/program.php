<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") 
{
    $broj = isset($_GET["broj"]) ? $_GET["broj"] : '';
    $operacija = isset($_GET["operacija"]) ? $_GET["operacija"] : '';

    if (empty($broj) || empty($operacija)) 
	{
        print("Molim unesite broj i operaciju");
        exit; 
    }

    switch ($operacija) 
	{
        case 'KVADRAT':
            $rezultat = pow($broj, 2);
            break;
        case 'KUB':
            $rezultat = pow($broj, 3);
            break;
        default:
            echo "Nepoznata operacija";
            exit; 
    }
    echo "Poslali ste broj: <strong>$broj</strong><br>";
    echo "Operacija je: <strong>$operacija</strong><br>";
    echo "Rezultat je: <strong>$rezultat</strong><br>";
}
?>