<!DOCTYPE html>
<head>
    <title>PHP</title>
<?php
function CheckPwd($lozinka) 
{
    if (strlen($lozinka) < 6)
	{
        return 0;
    }
    if (!preg_match('/[0-9]/', $lozinka) || !preg_match('/[a-zA-Z]/', $lozinka)) 
	{
        return 0;
    }

  return 1;
}

$korisnickoIme = '';
$lozinka = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $korisnickoIme = $_POST["korisnickoIme"];
    $lozinka = $_POST["lozinka"];

    $validacijaLozinke = CheckPwd($lozinka);
    print("Korisničko ime je $korisnickoIme, a lozinka je $lozinka");

    if ($validacijaLozinke == false)
	{
        print(" i nije valjana.");
    } 
}
?>
</head>
<body>
    <form method="post" action="provjera.php">
        <label for="korisnickoIme">Korisničko ime:</label>
        <input type="text" name="korisnickoIme" value="<?php echo $korisnickoIme; ?>" required>
        <br>
        <label for="lozinka">Lozinka:</label>
        <input type="password" name="lozinka" required>
        <br>
        <input type="submit" value="Pošalji">
    </form>
</body>
</html>